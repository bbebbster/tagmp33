const state = {
  fileId: null,
  originalName: '',
  selectedCoverUrl: '',
  covers: [],
  lastTags: []
};

const el = {
  keyStatus: document.querySelector('#keyStatus'),
  dropZone: document.querySelector('#dropZone'),
  mp3Input: document.querySelector('#mp3Input'),
  workspace: document.querySelector('#workspace'),
  fileName: document.querySelector('#fileName'),
  lookupBtn: document.querySelector('#lookupBtn'),
  downloadBtn: document.querySelector('#downloadBtn'),
  covers: document.querySelector('#covers'),
  log: document.querySelector('#log'),
  title: document.querySelector('#title'),
  artist: document.querySelector('#artist'),
  album: document.querySelector('#album'),
  year: document.querySelector('#year'),
  era: document.querySelector('#era'),
  genre: document.querySelector('#genre'),
  trackNumber: document.querySelector('#trackNumber'),
  tagChips: document.querySelector('#tagChips'),
  coverTemplate: document.querySelector('#coverTemplate')
};

function setLog(message, type = 'info') {
  if (!message) {
    el.log.className = 'log hidden';
    el.log.textContent = '';
    return;
  }
  el.log.className = `log ${type}`;
  el.log.textContent = message;
}

function setBusy(button, busy, labelWhenFree) {
  button.disabled = busy;
  button.dataset.label = button.dataset.label || button.textContent;
  button.textContent = busy ? 'Working…' : (labelWhenFree || button.dataset.label);
}

function eraFromYear(yearValue) {
  const year = Number.parseInt(yearValue, 10);
  if (!Number.isFinite(year) || year < 1900) return '';
  const decade = Math.floor(year / 10) * 10;
  if (year < 1950) return 'pre-50s';
  return `${String(decade).slice(2)}s`;
}

function fillFields(data = {}) {
  el.title.value = data.title || '';
  el.artist.value = data.artist || '';
  el.album.value = data.album || '';
  el.year.value = data.year || '';
  el.era.value = data.era || eraFromYear(data.year) || '';
  el.genre.value = data.genre || '';
  el.trackNumber.value = data.trackNumber || '';
}

function renderTags(tags = []) {
  state.lastTags = tags;
  el.tagChips.innerHTML = '';
  for (const tag of tags) {
    const chip = document.createElement('span');
    chip.className = 'chip';
    chip.textContent = tag;
    el.tagChips.appendChild(chip);
  }
}

function renderCovers(covers = []) {
  state.covers = covers;
  state.selectedCoverUrl = covers[0]?.url || '';
  el.downloadBtn.disabled = !state.fileId;

  if (!covers.length) {
    el.covers.className = 'covers empty';
    el.covers.textContent = 'No artwork came back. You can still download the MP3 with text tags only.';
    return;
  }

  el.covers.className = 'covers';
  el.covers.innerHTML = '';

  covers.forEach((cover, index) => {
    const node = el.coverTemplate.content.firstElementChild.cloneNode(true);
    const img = node.querySelector('img');
    const meta = node.querySelector('.cover-meta');
    img.src = cover.url;
    img.alt = cover.label ? `Cover for ${cover.label}` : 'Album cover candidate';
    meta.textContent = `${cover.source}${cover.label ? ` · ${cover.label}` : ''}`;
    if (index === 0) node.classList.add('selected');

    node.addEventListener('click', () => {
      state.selectedCoverUrl = cover.url;
      document.querySelectorAll('.cover').forEach((item) => item.classList.remove('selected'));
      node.classList.add('selected');
    });

    el.covers.appendChild(node);
  });
}

async function checkHealth() {
  try {
    const response = await fetch('/api/health');
    const data = await response.json();
    if (data.hasLastFmKey) {
      el.keyStatus.textContent = 'Last.fm key connected';
      el.keyStatus.classList.add('ok');
    } else {
      el.keyStatus.textContent = 'Add LASTFM_API_KEY to .env';
      el.keyStatus.classList.add('bad');
    }
  } catch {
    el.keyStatus.textContent = 'Server not reachable';
    el.keyStatus.classList.add('bad');
  }
}

async function inspectFile(file) {
  if (!file) return;
  if (!file.name.toLowerCase().endsWith('.mp3')) {
    setLog('Please choose an MP3 file.', 'error');
    return;
  }

  setLog('Reading MP3 tags…');
  const form = new FormData();
  form.append('mp3', file);

  try {
    const response = await fetch('/api/inspect', { method: 'POST', body: form });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Could not inspect this MP3.');

    state.fileId = data.fileId;
    state.originalName = data.originalName;
    state.selectedCoverUrl = '';
    fillFields(data.existing);
    renderTags([]);
    renderCovers([]);
    el.workspace.classList.remove('hidden');
    el.fileName.textContent = `${data.originalName}${data.existing.hasEmbeddedCover ? ' · embedded cover found' : ''}`;
    setLog('Loaded. Check the title/artist, then look it up.');
  } catch (err) {
    setLog(err.message, 'error');
  }
}

async function lookupTrack() {
  if (!state.fileId) {
    setLog('Upload an MP3 first.', 'error');
    return;
  }

  setBusy(el.lookupBtn, true);
  setLog('Looking up track metadata and artwork…');

  try {
    const response = await fetch('/api/lookup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: el.title.value,
        artist: el.artist.value,
        album: el.album.value,
        year: el.year.value
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Lookup failed.');

    fillFields({
      ...data.metadata,
      trackNumber: el.trackNumber.value
    });
    renderTags(data.metadata.tags || []);
    renderCovers(data.covers || []);

    const warnings = data.warnings && data.warnings.length ? ` Warnings: ${data.warnings.join(' | ')}` : '';
    setLog(`Found metadata${data.covers?.length ? ` and ${data.covers.length} cover option(s)` : ''}.${warnings}`);
  } catch (err) {
    setLog(err.message, 'error');
  } finally {
    setBusy(el.lookupBtn, false, 'Look up on Last.fm');
  }
}

async function downloadTagged() {
  if (!state.fileId) return;

  setBusy(el.downloadBtn, true);
  setLog('Writing ID3 tags and embedding the selected cover…');

  try {
    const response = await fetch('/api/tag', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fileId: state.fileId,
        title: el.title.value,
        artist: el.artist.value,
        album: el.album.value,
        year: el.year.value,
        era: el.era.value,
        genre: el.genre.value,
        trackNumber: el.trackNumber.value,
        coverUrl: state.selectedCoverUrl
      })
    });

    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.error || 'Could not tag the MP3.');
    }

    const blob = await response.blob();
    const disposition = response.headers.get('content-disposition') || '';
    const filenameMatch = disposition.match(/filename="?([^";]+)"?/i);
    const filename = filenameMatch ? decodeURIComponent(filenameMatch[1]) : `${el.artist.value} - ${el.title.value}.mp3`;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);

    setLog('Downloaded a new tagged MP3. Your original upload was not overwritten.');
  } catch (err) {
    setLog(err.message, 'error');
  } finally {
    setBusy(el.downloadBtn, false, 'Download tagged MP3');
    el.downloadBtn.disabled = !state.fileId;
  }
}

el.mp3Input.addEventListener('change', (event) => inspectFile(event.target.files[0]));
el.lookupBtn.addEventListener('click', lookupTrack);
el.downloadBtn.addEventListener('click', downloadTagged);
el.year.addEventListener('input', () => {
  const era = eraFromYear(el.year.value);
  if (era) el.era.value = era;
});

['dragenter', 'dragover'].forEach((name) => {
  el.dropZone.addEventListener(name, (event) => {
    event.preventDefault();
    el.dropZone.classList.add('dragging');
  });
});

['dragleave', 'drop'].forEach((name) => {
  el.dropZone.addEventListener(name, (event) => {
    event.preventDefault();
    el.dropZone.classList.remove('dragging');
  });
});

el.dropZone.addEventListener('drop', (event) => {
  const file = event.dataTransfer.files[0];
  inspectFile(file);
});

checkHealth();
